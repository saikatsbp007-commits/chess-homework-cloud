export class Chess {
  constructor(fen) { this._fen = fen || 'startpos'; }
  fen() { return this._fen; }
  move() { throw new Error('Chess stub: move not implemented in protocol-only tests'); }
  isCheck() { return false; } isCheckmate() { return false; } isStalemate() { return false; }
  isThreefoldRepetition() { return false; } isInsufficientMaterial() { return false; }
  isDraw() { return false; } isGameOver() { return false; }
  pgn() { return ''; }
}
