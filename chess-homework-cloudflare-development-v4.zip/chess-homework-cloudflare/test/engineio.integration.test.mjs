import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { ChessHub } from '../src/index.js';

class FakeSql {
  constructor() { this.rooms = new Map(); this.games = new Map(); }
  exec(q, ...a) {
    const s=q.replace(/\s+/g,' ').trim().toLowerCase();
    if (s.startsWith('create table')) return {toArray:()=>[],one:()=>null};
    if (s.startsWith('insert or replace into rooms')) { this.rooms.set(a[0],{room_id:a[0],data:a[1],updated_at:a[2]}); return {toArray:()=>[]}; }
    if (s.startsWith('select data from rooms')) { const r=this.rooms.get(a[0]); return {one:()=>r?{data:r.data}:null,toArray:()=>r?[r]:[]}; }
    if (s.startsWith('select game_id, room_id, finished_at, data from games')) return {toArray:()=>[...this.games.values()]};
    if (s.startsWith('select data from games')) { const r=this.games.get(a[0]); return {one:()=>r?{data:r.data}:null}; }
    if (s.startsWith('insert or replace into games')) { this.games.set(a[0],{game_id:a[0],room_id:a[1],data:a[2],finished_at:a[3]}); return {toArray:()=>[]}; }
    throw new Error('Unexpected SQL: '+q);
  }
}
function makeHub() {
  const sql=new FakeSql(); const ctx={storage:{sql},blockConcurrencyWhile(fn){fn();}};
  const hub=new ChessHub(ctx,{ROOM_AUTH_SECRET:'integration-test-secret-0123456789',APP_VERSION:'test'});
  return hub;
}
function req(path,method='GET',body='') { return new Request('https://hub.test'+path,{method,body:method==='POST'?body:undefined,headers:method==='POST'?{'content-type':'text/plain'}:{}}); }
const path='/socket.io/?EIO=4&transport=polling';
async function post(hub,sid,packet) { return hub.fetch(req(path+'&sid='+sid,'POST',packet)); }
async function poll(hub,sid) { return hub.fetch(req(path+'&sid='+sid)); }
async function packet(response) { return response.text(); }

test('Engine.IO v4 polling handshake returns session id and disables upgrade', async()=>{
  const hub=makeHub(); const r=await hub.fetch(req(path)); const body=await packet(r);
  assert.equal(r.status,200); assert.match(body,/^0\{"sid":"[^"]+","upgrades":\[\]/);
  const sid=JSON.parse(body.slice(1)).sid; assert.ok(hub.transports.has(sid));
});

test('Socket.IO namespace connect over polling returns connect packet', async()=>{
  const hub=makeHub(); const open=await packet(await hub.fetch(req(path))); const sid=JSON.parse(open.slice(1)).sid;
  assert.equal((await post(hub,sid,'40')).status,200);
  assert.match(await packet(await poll(hub,sid)),/^40\{"sid":"/);
});

test('Socket.IO event acknowledgement and room welcome survive polling round-trip', async()=>{
  const hub=makeHub(); const open=await packet(await hub.fetch(req(path))); const sid=JSON.parse(open.slice(1)).sid;
  await post(hub,sid,'40'); await poll(hub,sid);
  const payload={roomId:'TEST42',playerId:'p1',playerName:'Phone A',preferredSide:'w'};
  await post(hub,sid,'42'+JSON.stringify(['room:create',payload]));
  const out=await packet(await poll(hub,sid));
  assert.match(out,/42\["room:welcome"/);
  const welcome=JSON.parse(out.slice(2)); assert.equal(welcome[1].roomId,'TEST42'); assert.equal(welcome[1].seat,'w'); assert.ok(welcome[1].seatAuthToken);
});

test('polling POST supports Engine.IO record-separated packets', async()=>{
  const hub=makeHub(); const open=await packet(await hub.fetch(req(path))); const sid=JSON.parse(open.slice(1)).sid;
  const r=await post(hub,sid,'2'+String.fromCharCode(30)+'40');
  assert.equal(r.status,200); assert.match(await packet(await poll(hub,sid)),/^3/);
});

test('unknown polling sid is rejected and oversized body is rejected', async()=>{
  const hub=makeHub();
  assert.equal((await hub.fetch(req(path+'&sid=missing','POST','40'))).status,400);
  const open=await packet(await hub.fetch(req(path))); const sid=JSON.parse(open.slice(1)).sid;
  assert.equal((await post(hub,sid,'x'.repeat(1000001))).status,413);
});

test('Worker routes Engine.IO requests to the shared Durable Object and exposes health', async()=>{
  const hub=makeHub(); let routed=0;
  const env={APP_VERSION:'test',CHESS_HUB:{idFromName:n=>n,get:id=>({fetch:r=>{routed++;return hub.fetch(r);}})}};
  const health=await worker.fetch(new Request('https://worker.test/api/health'),env);
  assert.equal(health.status,200); assert.equal((await health.json()).ok,true);
  const r=await worker.fetch(req(path),env); assert.equal(r.status,200); assert.equal(routed,1);
});
