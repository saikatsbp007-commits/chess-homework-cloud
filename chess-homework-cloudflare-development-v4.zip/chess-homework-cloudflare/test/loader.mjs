export async function resolve(specifier, context, nextResolve) {
  if (specifier === 'chess.js') return { url: new URL('./chess-stub.mjs', import.meta.url).href, shortCircuit: true };
  return nextResolve(specifier, context);
}
