# Chess Homework — Cloudflare migration development build

**Development build only. Do not replace the current production Worker or rely on this package for live games yet.**

## Changes in this revision
- Adds an Engine.IO v4 HTTP long-polling handshake (`GET`), packet POST (`POST`), queued polling responses, heartbeat packets, and session IDs.
- Keeps the Engine.IO v4 WebSocket handshake.
- Advertises no polling-to-WebSocket upgrade; a polling session remains on polling. This avoids pretending that a cross-transport upgrade is supported when it is not implemented.
- Routes both `/socket.io` and `/socket.io/` through the Durable Object.
- Handles Engine.IO close packets and retains signed HMAC-SHA256 seat tokens, SQLite room/game storage, PGN generation, and replay/history API.

## Validation performed
- `node --check src/index.js` passed.
- ZIP integrity check passed.
- Static route inspection confirms both Engine.IO v4 transports are routed to the same Durable Object.

## Not yet validated — deployment blockers
- No Cloudflare deployment has been performed.
- No Engine.IO / Socket.IO client integration test has been run against a live Worker.
- No test has been run with the uploaded APK or two physical Android devices.
- Full original server parity is incomplete: authoritative chess clocks/timeouts, room lease/presence semantics, complete WebRTC signalling sequence, rematch handshake/side swap, every payload variant, and reconnect edge cases still need porting and verification.
- Polling requests are held for up to 20 seconds and use in-memory session queues; Durable Object eviction/restart behaviour and concurrent poll handling require integration testing before production.
- Game history and PGN are initial implementation only. Draw agreement/resignation/timeout persistence paths need complete test coverage.
- Engine-based analysis and accuracy grading are not implemented; current history supports stored moves, PGN and replay data only.

## Deployment secrets
Set `ROOM_AUTH_SECRET` as a Cloudflare Worker secret (random, at least 32 characters). Never commit secrets, `.env` files, room data, or `node_modules`.

Keep the Cloudflare account on Workers Free. Do not enable paid add-ons. Check current quotas before production use.

## Automated protocol tests (v4 development checkpoint)

Run:

```bash
npm test
npm run check
```

The six automated tests exercise the Engine.IO v4 polling handshake, Socket.IO namespace connection, `room:create` event delivery and acknowledgement path, Engine.IO packet separators, invalid/oversized polling requests, and Worker-to-Durable-Object routing. These are protocol-adapter tests using a deliberately minimal `chess.js` test double; they do **not** validate legal chess moves, Cloudflare's production Durable Objects runtime, a real `socket.io-client`, WebSocket upgrades, or the Android APK.

## Deployment test status

Not deployed or remotely verified. The current Worker URL could not be reached from this build environment (DNS/network resolution failed), and no Cloudflare deployment credentials are available in this session. Do not treat the existing Hello World Worker as this code. The next deployment gate is to run `npm ci`, `npm test`, then deploy from a GitHub Actions runner with `ROOM_AUTH_SECRET` configured as a secret and test the health endpoint plus two physical Android devices. Keep the current production Worker unchanged until those checks pass.
