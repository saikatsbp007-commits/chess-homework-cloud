import { Chess } from 'chess.js';

const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
const b64url = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/=/g, '').replace(/\+/g, '-').replace(/\//g, '_');
const unb64url = (s) => Uint8Array.from(atob(s.replace(/-/g, '+').replace(/_/g, '/') + '='.repeat((4 - s.length % 4) % 4)), c => c.charCodeAt(0));
async function seatToken(env, roomId, playerId, seat) {
  if (!env.ROOM_AUTH_SECRET || env.ROOM_AUTH_SECRET.length < 16) throw new Error('ROOM_AUTH_SECRET is not configured');
  const payload = b64url(new TextEncoder().encode(JSON.stringify({r:roomId,p:playerId,s:seat,exp:Date.now()+86400000})));
  const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(env.ROOM_AUTH_SECRET), {name:'HMAC',hash:'SHA-256'}, false, ['sign']);
  const sig = b64url(await crypto.subtle.sign('HMAC', key, new TextEncoder().encode(payload)));
  return `v1.${payload}.${sig}`;
}
async function verifySeatToken(env, token, roomId) {
  try { if (!token || !env.ROOM_AUTH_SECRET) return null; const [v,p,s] = String(token).split('.'); if(v!=='v1'||!p||!s) return null;
    const key = await crypto.subtle.importKey('raw', new TextEncoder().encode(env.ROOM_AUTH_SECRET), {name:'HMAC',hash:'SHA-256'}, false, ['verify']);
    const ok = await crypto.subtle.verify('HMAC', key, unb64url(s), new TextEncoder().encode(p)); if(!ok) return null;
    const d = JSON.parse(new TextDecoder().decode(unb64url(p))); return d.r===roomId && d.exp>Date.now() && ['w','b','spectator'].includes(d.s) ? d : null;
  } catch { return null; }
}
const json = (data, status = 200) => new Response(JSON.stringify(data), { status, headers: JSON_HEADERS });

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/health') {
      return json({ ok: true, service: 'chess-homework-cloudflare-development', version: env.APP_VERSION, transport: 'socket.io-engine-v4-websocket-and-polling', storage: 'durable-objects-sqlite', history: true, analysis: 'replay-and-pgn; engine-analysis-not-yet-enabled' });
    }
    if (url.pathname === '/socket.io/' || url.pathname === '/socket.io') {
      if (url.searchParams.get('EIO') !== '4') return new Response('Unsupported Engine.IO version', {status:400});
      const transport = url.searchParams.get('transport');
      if (transport === 'websocket' && request.headers.get('Upgrade')?.toLowerCase() !== 'websocket') return new Response('WebSocket upgrade required', {status:426});
      if (transport !== 'websocket' && transport !== 'polling') return new Response('Unsupported transport', {status:400});
      const id = env.CHESS_HUB.idFromName('global-chess-hub');
      return env.CHESS_HUB.get(id).fetch(request);
    }
    if (url.pathname === '/api/games' && request.method === 'GET') {
      const id = env.CHESS_HUB.idFromName('global-chess-hub');
      return env.CHESS_HUB.get(id).fetch(new Request('https://hub.internal/history'));
    }
    if (url.pathname.startsWith('/api/games/') && request.method === 'GET') {
      const gameId = decodeURIComponent(url.pathname.split('/').pop() || '');
      const id = env.CHESS_HUB.idFromName('global-chess-hub');
      return env.CHESS_HUB.get(id).fetch(new Request(`https://hub.internal/history/${encodeURIComponent(gameId)}`));
    }
    return json({ ok: false, error: 'Not found' }, 404);
  }
};

export class ChessHub {
  constructor(ctx, env) {
    this.ctx = ctx; this.env = env; this.sessions = new Map(); this.sockets = new Map(); this.transports = new Map(); this.pendingPolls = new Map(); this.pingTimer = null;
    this.ctx.blockConcurrencyWhile(async () => {
      this.ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS rooms (room_id TEXT PRIMARY KEY, data TEXT NOT NULL, updated_at INTEGER NOT NULL)`);
      this.ctx.storage.sql.exec(`CREATE TABLE IF NOT EXISTS games (game_id TEXT PRIMARY KEY, room_id TEXT NOT NULL, data TEXT NOT NULL, finished_at INTEGER NOT NULL)`);
      this.pingTimer = setInterval(() => { for (const sid of this.transports.keys()) this.send(sid, '2'); }, 25000); this.pingTimer?.unref?.();
    });
  }
  async fetch(request) {
    const url = new URL(request.url);
    if (url.pathname === '/history') {
      const rows = this.ctx.storage.sql.exec('SELECT game_id, room_id, finished_at, data FROM games ORDER BY finished_at DESC LIMIT 100').toArray();
      return json({ ok: true, games: rows.map(r => { const d = JSON.parse(r.data); return { gameId:r.game_id, roomId:r.room_id, finishedAt:r.finished_at, white:d.white?.name, black:d.black?.name, winner:d.winner, endReason:d.endReason, ply:d.moves?.length||0 }; }) });
    }
    if (url.pathname.startsWith('/history/')) {
      const gid = decodeURIComponent(url.pathname.slice('/history/'.length));
      const row = this.ctx.storage.sql.exec('SELECT data FROM games WHERE game_id = ?', gid).one();
      return row ? json({ ok:true, game:JSON.parse(row.data) }) : json({ ok:false,error:'Game not found' },404);
    }
    // Engine.IO v4 polling transport. Polling is advertised without an upgrade
    // because Durable Objects cannot safely share one Engine.IO session across
    // concurrent polling and WebSocket transports in this lightweight adapter.
    if (url.pathname === '/socket.io/' && url.searchParams.get('transport') === 'polling') {
      if (request.method === 'OPTIONS') return new Response(null, { status:204, headers:{'access-control-allow-origin':'*','access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'content-type'} });
      const sid = url.searchParams.get('sid');
      if (!sid && request.method === 'GET') {
        const newSid = crypto.randomUUID();
        this.transports.set(newSid, { kind:'polling', queue:[], closed:false });
        const open = '0' + JSON.stringify({ sid:newSid, upgrades:[], pingInterval:25000, pingTimeout:20000, maxPayload:1000000 });
        return new Response(open, { headers:{'content-type':'text/plain; charset=UTF-8','cache-control':'no-store','access-control-allow-origin':'*'} });
      }
      if (!sid || !this.transports.has(sid) || this.transports.get(sid).kind !== 'polling') return new Response('Unknown session', {status:400});
      if (request.method === 'POST') {
        const body = await request.text();
        if (body.length > 1000000) return new Response('Payload too large', {status:413});
        for (const packet of body.split(String.fromCharCode(30))) if (packet) await this.onMessage(sid, packet);
        return new Response('ok', {headers:{'content-type':'text/plain; charset=UTF-8','cache-control':'no-store','access-control-allow-origin':'*'}});
      }
      if (request.method === 'GET') {
        const t = this.transports.get(sid);
        if (t.queue.length) return this.pollResponse(t.queue.splice(0).join(String.fromCharCode(30)));
        return await new Promise(resolve => {
          const timer = setTimeout(() => { this.pendingPolls.delete(sid); resolve(this.pollResponse('6')); }, 20000);
          this.pendingPolls.set(sid, { resolve, timer });
        });
      }
      return new Response('Method not allowed', {status:405});
    }
    const pair = new WebSocketPair(); const client = pair[0], server = pair[1];
    server.accept(); const sid = url.searchParams.get('sid') || crypto.randomUUID();
    this.transports.set(sid, { kind:'websocket', queue:[], closed:false });
    this.sockets.set(sid, server);
    if (!url.searchParams.has('sid')) server.send('0' + JSON.stringify({ sid, upgrades:[], pingInterval:25000, pingTimeout:20000, maxPayload:1000000 }));
    server.addEventListener('message', e => this.onMessage(sid, String(e.data)));
    server.addEventListener('close', () => this.onClose(sid));
    server.addEventListener('error', () => this.onClose(sid));
    return new Response(null, { status:101, webSocket:client });
  }
  pollResponse(body) { return new Response(body, {headers:{'content-type':'text/plain; charset=UTF-8','cache-control':'no-store','access-control-allow-origin':'*'}}); }
  send(sid, packet) {
    const ws=this.sockets.get(sid);
    if (ws && ws.readyState===1) { try { ws.send(packet); } catch {} return; }
    const t=this.transports.get(sid); if (!t || t.closed) return;
    const pending=this.pendingPolls.get(sid);
    if (pending) { clearTimeout(pending.timer); this.pendingPolls.delete(sid); pending.resolve(this.pollResponse(packet)); }
    else t.queue.push(packet);
  }
  emit(sid, event, data) { this.send(sid, '42'+JSON.stringify([event,data])); }
  emitRoom(roomId,event,data,except) { for (const [sid,s] of this.sessions) if(s.roomId===roomId && sid!==except) this.emit(sid,event,data); }
  async onMessage(sid, packet) {
    if (packet === '1') { this.onClose(sid); return; }
    if (packet === '2') { this.send(sid,'3'); return; }
    if (packet.startsWith('3')) return;
    if (packet === '40' || packet.startsWith('40{')) { this.send(sid,'40'+JSON.stringify({sid})); return; }
    if (!packet.startsWith('42')) return;
    let ackId=null, body=packet.slice(2);
    const m=body.match(/^(\d+)(\[.*)$/s); if(m){ackId=m[1];body=m[2];}
    let arr; try { arr=JSON.parse(body); } catch { return; }
    if(!Array.isArray(arr)||typeof arr[0]!=='string') return;
    const [event,payload={}] = arr; let result;
    try { result=await this.handleEvent(sid,event,payload||{}); }
    catch(err){ result={ok:false,code:'SERVER_ERROR',error:String(err?.message||err)}; }
    if(ackId!==null) this.send(sid,'43'+ackId+JSON.stringify([result]));
  }
  room(id) { const r=this.ctx.storage.sql.exec('SELECT data FROM rooms WHERE room_id = ?',id).one(); return r?JSON.parse(r.data):null; }
  save(room) { this.ctx.storage.sql.exec('INSERT OR REPLACE INTO rooms(room_id,data,updated_at) VALUES(?,?,?)',room.roomId,JSON.stringify(room),Date.now()); }
  snapshot(r) { return { roomId:r.roomId,fen:r.fen,turn:r.turn,inCheck:r.inCheck,isCheckmate:r.isCheckmate,isStalemate:r.isStalemate,isThreefoldRepetition:r.isThreefoldRepetition,isInsufficientMaterial:r.isInsufficientMaterial,isDraw:r.isDraw,ply:r.moves.length,moves:r.moves,capturedByWhite:[],capturedByBlack:[],timeControl:r.timeControl,whiteMs:r.whiteMs,blackMs:r.blackMs,clockRunning:r.status==='active',status:r.status,winner:r.winner,endReason:r.endReason,drawOfferBy:r.drawOfferBy,rematchRequestedBy:r.rematchRequestedBy,white:r.white,black:r.black,spectatorCount:r.spectatorCount||0,chat:r.chat||[],createdAt:r.createdAt,updatedAt:r.updatedAt,expiresAt:r.expiresAt,serverNow:Date.now() }; }
  async handleEvent(sid,event,p={}) {
    if(event==='room:create') {
      const roomId=(String(p.roomId||'').toUpperCase().replace(/[^A-Z0-9]/g,'').slice(0,10))||Math.random().toString(36).slice(2,8).toUpperCase();
      if(this.room(roomId)) return {ok:false,code:'ROOM_EXISTS',error:'Room code already exists.'};
      const tc=p.timeControl||{}, initial=Math.max(30000,Math.min(7200000,Number(tc.initialMs)||600000)), inc=Math.max(0,Math.min(120000,Number(tc.incrementMs)||0));
      const seat=p.preferredSide==='b'?'b':'w', playerId=String(p.playerId||p.playerToken||crypto.randomUUID()), connId=String(p.connId||crypto.randomUUID()), name=String(p.playerName||'Player').slice(0,40), now=Date.now();
      const room={roomId,fen:new Chess().fen(),turn:'w',inCheck:false,isCheckmate:false,isStalemate:false,isThreefoldRepetition:false,isInsufficientMaterial:false,isDraw:false,moves:[],timeControl:{initialMs:initial,incrementMs:inc,label:tc.label||`${initial/60000}+${inc/1000}`},whiteMs:initial,blackMs:initial,status:'waiting',winner:null,endReason:null,drawOfferBy:null,rematchRequestedBy:null,white:seat==='w'?{playerId,name,connected:true,connId}:null,black:seat==='b'?{playerId,name,connected:true,connId}:null,chat:[],createdAt:now,updatedAt:now,expiresAt:now+86400000,appliedMoveIds:[]};
      this.save(room); this.sessions.set(sid,{roomId,seat,playerId,connId,name});
      const seatAuthToken=await seatToken(this.env,roomId,playerId,seat); const welcome={ok:true,roomId,seat,playerId,connId,seatAuthToken,signalSeq:0,room:this.snapshot(room)};
      this.emit(sid,'room:welcome',welcome); return welcome;
    }
    if(event==='room:join') {
      const roomId=String(p.roomId||'').toUpperCase().replace(/[^A-Z0-9]/g,''); const room=this.room(roomId);
      if(!room||room.expiresAt<Date.now()) return {ok:false,code:'ROOM_NOT_FOUND',error:'Room not found or expired.'};
      let playerId=String(p.playerId||p.playerToken||crypto.randomUUID()); const connId=String(p.connId||crypto.randomUUID()),name=String(p.playerName||'Player').slice(0,40);
      const token=await verifySeatToken(this.env,p.seatAuthToken,roomId);
      if(token) playerId=token.p;
      let seat='spectator', reconnected=false;
      if (token && token.p===room.white?.playerId && token.s==='w') { seat='w'; reconnected=true; }
      else if (token && token.p===room.black?.playerId && token.s==='b') { seat='b'; reconnected=true; }
      else if (room.white?.playerId===playerId) { seat='w'; reconnected=true; }
      else if (room.black?.playerId===playerId) { seat='b'; reconnected=true; }
      else if(!room.white) seat='w'; else if(!room.black) seat='b';
      if(seat==='w') room.white={playerId,name,connected:true,connId}; if(seat==='b') room.black={playerId,name,connected:true,connId}; if(room.white&&room.black&&room.status==='waiting')room.status='active';
      room.updatedAt=Date.now();this.save(room);this.sessions.set(sid,{roomId,seat,playerId,connId,name});
      const seatAuthToken=await seatToken(this.env,roomId,playerId,seat);
      const welcome={ok:true,roomId,seat,playerId,connId,seatAuthToken,reconnected,signalSeq:0,room:this.snapshot(room)};this.emit(sid,'room:welcome',welcome);this.emitRoom(roomId,'room:state',{room:this.snapshot(room),event:'opponent-joined'},sid);return welcome;
    }
    const sess=this.sessions.get(sid); if(!sess)return {ok:false,code:'NOT_IN_ROOM',error:'Not connected to an active room.'};
    const r=this.room(sess.roomId); if(!r)return {ok:false,code:'ROOM_NOT_FOUND',error:'Room not found.'};
    if(event==='room:leave'){this.sessions.delete(sid);return {ok:true};}
    if(event==='game:move') {
      if(r.status==='finished')return {ok:false,code:'GAME_FINISHED',error:'Game finished'};
      if(sess.seat!=='w' && sess.seat!=='b') return {ok:false,code:'SPECTATOR_ONLY',error:'Spectators cannot make moves'};
      if(sess.seat!==r.turn)return {ok:false,code:'OUT_OF_TURN',error:'Not your turn'};
      const moveId=String(p.moveId||''); if(moveId && r.appliedMoveIds.includes(moveId)) return {ok:true,duplicate:true,room:this.snapshot(r)};
      if(typeof p.expectedPly==='number' && p.expectedPly!==r.moves.length) return {ok:false,code:'STALE_STATE',error:'Board state is out of date'};
      if(!r.white||!r.black)return {ok:false,code:'WAITING_FOR_OPPONENT',error:'Waiting for opponent'};
      const game=new Chess(r.fen); let move; try{move=game.move({from:p.from,to:p.to,promotion:p.promotion||'q'});}catch{return {ok:false,code:'ILLEGAL_MOVE',error:'Illegal chess move'};}
      const now=Date.now(); const finalMoveId=moveId||crypto.randomUUID();
      const item={ply:r.moves.length+1,moveId:finalMoveId,san:move.san,lan:`${move.from}${move.to}${move.promotion||''}`,from:move.from,to:move.to,piece:move.piece,color:move.color,captured:move.captured,promotion:move.promotion,flags:move.flags,isCastle:move.isKingsideCastle()||move.isQueensideCastle(),isCheck:game.isCheck(),isCheckmate:game.isCheckmate(),fenAfter:game.fen(),whiteMs:r.whiteMs,blackMs:r.blackMs,at:now};
      r.moves.push(item);r.appliedMoveIds.push(finalMoveId);r.fen=game.fen();r.turn=game.turn();r.inCheck=game.isCheck();r.isCheckmate=game.isCheckmate();r.isStalemate=game.isStalemate();r.isThreefoldRepetition=game.isThreefoldRepetition();r.isInsufficientMaterial=game.isInsufficientMaterial();r.isDraw=game.isDraw();r.status=game.isGameOver()?'finished':'active';r.winner=game.isCheckmate()?move.color:game.isGameOver()?'draw':null;r.endReason=game.isCheckmate()?'checkmate':game.isStalemate()?'stalemate':game.isDraw()?'draw':null;r.updatedAt=now;r.expiresAt=now+86400000;
      this.save(r); if(r.status==='finished')this.saveCompletedGame(r);
      this.emitRoom(r.roomId,'room:state',{room:this.snapshot(r),lastMove:item}); return {ok:true,move:item,room:this.snapshot(r)};
    }
    if(event==='game:resign'){r.status='finished';r.winner=sess.seat==='w'?'b':'w';r.endReason='resign';r.updatedAt=Date.now();this.save(r);this.saveCompletedGame(r);this.emitRoom(r.roomId,'room:state',{room:this.snapshot(r)});return {ok:true,room:this.snapshot(r)};}
    if(event==='game:offer-draw'){r.drawOfferBy=sess.seat;this.save(r);this.emitRoom(r.roomId,'room:state',{room:this.snapshot(r)});return {ok:true,room:this.snapshot(r)};}
    if(event==='game:respond-draw'){if(!r.drawOfferBy||r.drawOfferBy===sess.seat)return {ok:false,code:'NO_DRAW_OFFER',error:'No draw offer from opponent'};if(p.accept){r.status='finished';r.winner='draw';r.endReason='agreement';this.saveCompletedGame(r);}r.drawOfferBy=null;this.save(r);this.emitRoom(r.roomId,'room:state',{room:this.snapshot(r)});return {ok:true,room:this.snapshot(r)};}
    if(event==='chat:send'){const msg={id:crypto.randomUUID(),name:sess.name,text:String(p.text||p.message||'').slice(0,500),at:Date.now()};r.chat=[...(r.chat||[]),msg].slice(-100);this.save(r);this.emitRoom(r.roomId,'chat:message',msg);return {ok:true,room:this.snapshot(r)};}
    if(event==='player:rename'){sess.name=String(p.name||'').slice(0,40);if(sess.seat==='w'&&r.white)r.white.name=sess.name;if(sess.seat==='b'&&r.black)r.black.name=sess.name;this.save(r);this.emitRoom(r.roomId,'room:state',{room:this.snapshot(r)});return {ok:true,room:this.snapshot(r)};}
    if(event==='game:rematch'){if(sess.seat!=='w'&&sess.seat!=='b')return {ok:false,code:'SPECTATOR_ONLY',error:'Spectators cannot start a rematch'};if(r.status!=='finished')return {ok:false,code:'GAME_NOT_FINISHED',error:'Rematch is available after the game finishes'};r.fen=new Chess().fen();r.moves=[];r.turn='w';r.status='waiting';r.winner=null;r.endReason=null;r.whiteMs=r.blackMs=r.timeControl.initialMs;r.appliedMoveIds=[];this.save(r);this.emitRoom(r.roomId,'room:state',{room:this.snapshot(r)});return {ok:true,room:this.snapshot(r)};}
    if(event==='webrtc:signal'){this.emitRoom(r.roomId,'webrtc:signal',p,sid);return {ok:true};}
    if(event==='webrtc:media-state'){this.emitRoom(r.roomId,'room:state',{room:this.snapshot(r)});return {ok:true};}
    return {ok:false,code:'UNKNOWN_EVENT',error:`Unsupported event: ${event}`};
  }
  saveCompletedGame(r){const gameId=`${r.roomId}-${r.updatedAt}`;const data={gameId,roomId:r.roomId,white:r.white,black:r.black,winner:r.winner,endReason:r.endReason,fen:r.fen,moves:r.moves,createdAt:r.createdAt,finishedAt:r.updatedAt,pgn:this.makePgn(r)};this.ctx.storage.sql.exec('INSERT OR REPLACE INTO games(game_id,room_id,data,finished_at) VALUES(?,?,?,?)',gameId,r.roomId,JSON.stringify(data),r.updatedAt);}
  makePgn(r){const g=new Chess();for(const m of r.moves){try{g.move({from:m.from,to:m.to,promotion:m.promotion||'q'});}catch{}}const result=r.winner==='w'?'1-0':r.winner==='b'?'0-1':'1/2-1/2';return `[Event "Chess Homework Online"]\n[Site "Cloudflare"]\n[Date "${new Date(r.updatedAt).toISOString().slice(0,10).replaceAll('-','.')}"]\n[White "${r.white?.name||'White'}"]\n[Black "${r.black?.name||'Black'}"]\n[Result "${result}"]\n\n${g.pgn({maxWidth:80, newline:'\n'})} ${result}`;}
  onClose(sid){const s=this.sessions.get(sid);this.sessions.delete(sid);this.sockets.delete(sid);const t=this.transports.get(sid);if(t)t.closed=true;const poll=this.pendingPolls.get(sid);if(poll){clearTimeout(poll.timer);poll.resolve(this.pollResponse('1'));this.pendingPolls.delete(sid);}this.transports.delete(sid);if(!s)return;const r=this.room(s.roomId);if(!r)return;if(s.seat==='w'&&r.white)r.white.connected=false;if(s.seat==='b'&&r.black)r.black.connected=false;r.updatedAt=Date.now();this.save(r);this.emitRoom(r.roomId,'room:state',{room:this.snapshot(r),event:'player-disconnected'});}
}
